  
  <?php $__env->startSection('content'); ?>
      <!-- ======= Hero Section ======= -->
      <section id="hero">
          <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

              <div class="carousel-inner" role="listbox">

                  <!-- Slide -->
                  <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="carousel-item active" style="background-image: url(<?php echo e(asset($item->photo)); ?>);">
                          <div class="carousel-container">
                              <div class="carousel-content animate__animated animate__fadeInUp">
                                  <h2>Welcome to <span>Company</span></h2>
                                  <p><?php echo e($item->description); ?></p>
                                  
                              </div>
                          </div>
                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div>

              <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
              </a>

              <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
                  <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
              </a>

              <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

          </div>
      </section><!-- End Hero -->

      <main id="main">

          <!-- ======= About Us Section ======= -->
          <section id="about-us" class="about-us">
              <div class="container" data-aos="fade-up">

                  <div class="section-title">
                      <h2>About Us</h2>
                  </div>

                  <div class="row content">
                      <div class="col-lg-6" data-aos="fade-right">
                          <h2><?php echo e($about->title); ?></h2>
                          <h3><?php echo e($about->short_text); ?></h3>
                      </div>
                      <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
                          <p>
                              <?php echo e($about->description); ?>

                          </p>
                          
                      </div>
                  </div>

              </div>
          </section><!-- End About Us Section -->

          <!-- ======= Services Section ======= -->
    

        <!-- ======= Gallery Album Section ======= -->
        <section id="about-us" class="about-us">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Gallery Album</h2>
                </div>

                <div class="row content">
                    <div class="row">

                        <!-- Gallery item -->
                        <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                            <div class="bg-white rounded shadow-sm"><img src="<?php echo e($item->thumbnail); ?>" alt="" class="img-fluid card-img-top">
                            <div class="p-4">
                                <h5> <a href="<?php echo e(route('album.image',$item->id)); ?>" class="text-dark"><?php echo e($item->title); ?></a></h5>
                                
                            </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>

            </div>
        </section><!-- End Gallery Album Section -->

          <!-- ======= Gallery Section ======= -->
          

          <!-- ======= Video Section ======= -->
          <section id="testimonials" class="testimonials section-bg">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Videos</h2>
                </div>

                <div class="row">

                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6" data-aos="fade-up">
                            <div class="testimonial-item mt-4">
                                <h4><?php echo e($video->title); ?></h4>
                                <br>
                                
                                <iframe width="560" height="315" src="<?php echo e($video->video_link); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                                <br>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section><!-- End Our Clients Section -->

          <!-- ======= Our Clients Section ======= -->
          <section id="clients" class="clients">
              <div class="container" data-aos="fade-up">

                  <div class="section-title">
                      <h2>Clients</h2>
                  </div>

                  <div class="row no-gutters clients-wrap clearfix" data-aos="fade-up">

                      <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="col-lg-3 col-md-4 col-6">
                              <div class="client-logo">
                                  <img src="<?php echo e(asset($row->logo)); ?>" class="img-fluid" alt="client logo">
                              </div>
                          </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </div>

              </div>
          </section><!-- End Our Clients Section -->

          <!-- ======= Testimonials Section ======= -->
          <section id="testimonials" class="testimonials section-bg">
              <div class="container" data-aos="fade-up">

                  <div class="section-title">
                      <h2>Testimonials</h2>
                  </div>

                  <div class="row">

                      <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="col-lg-6" data-aos="fade-up">
                              <div class="testimonial-item mt-4">
                                  <img src="<?php echo e($row->photo); ?>" class="testimonial-img" alt="testimonial img">
                                  <h3><?php echo e($row->name); ?></h3>
                                  <h4><?php echo e($row->designation); ?></h4>
                                  <p>
                                      <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                                      <?php echo e($row->description); ?>

                                      <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                                  </p>
                              </div>
                          </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </div>

              </div>
          </section><!-- End Testimonials Section -->

          <!-- ======= Our Team Section ======= -->
          <section id="team" class="team section-bg">
              <div class="container">

                  <div class="section-title" data-aos="fade-up">
                      <h2>Our <strong>Administrative</strong></h2>
                      
                  </div>

                  <div class="row">

                      <?php $__currentLoopData = $administrative; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
                              <div class="member" data-aos="fade-up">
                                  <div class="member-img">
                                      <img src="<?php echo e(asset($row->photo)); ?>" class="img-fluid" alt="administrative img">
                                      <div class="social">
                                          <a href=""><i class="bi bi-twitter"></i></a>
                                          <a href=""><i class="bi bi-facebook"></i></a>
                                          <a href=""><i class="bi bi-instagram"></i></a>
                                          <a href=""><i class="bi bi-linkedin"></i></a>
                                      </div>
                                  </div>
                                  <div class="member-info">
                                      <h4><?php echo e($row->name); ?></h4>
                                      <span><?php echo e($row->designation); ?></span>
                                  </div>
                              </div>
                          </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </div>

              </div>
          </section><!-- End Our Team Section -->

      </main><!-- End #main -->


      
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\omega_portfolio\resources\views/frontend/index.blade.php ENDPATH**/ ?>