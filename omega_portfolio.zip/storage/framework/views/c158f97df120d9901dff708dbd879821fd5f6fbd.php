<?php $__env->startSection('content'); ?>

<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>News</h2>
          <ol>
            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li>News</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog">
        <div class="container" data-aos="fade-up">
            <div class="row">
                <div class="col-lg-8 entries">

                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="entry">

                            <div class="entry-img">
                            <img src="<?php echo e($row->photo); ?>" alt="" class="img-fluid">
                            </div>

                            <h2 class="entry-title">
                            <a href="#"><?php echo e($row->title); ?></a>
                            </h2>

                            <div class="entry-meta">
                            <ul>
                                <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a href="#">Admin</a></li>
                                <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="#"><time datetime="2020-01-01"><?php echo e(Carbon\Carbon::parse($row->created_at)->format('d M Y')); ?></time></a></li>
                                
                            </ul>
                            </div>

                            <div class="entry-content">
                            <p>
                                <?php echo e($row->description); ?>

                            </p>
                            
                            </div>
                        </article>
                        <hr>
                        <br>
                        <!-- End blog entry -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    

                </div><!-- End blog entries list -->

                <div class="col-lg-4">

                    <div class="sidebar">

                    
                    <?php
                        $old_news=App\Models\News::where('status','active')->orderBy('id','ASC')->get()
                    ?>
                    <h3 class="sidebar-title">Previous News</h3>
                    <?php $__currentLoopData = $old_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="sidebar-item recent-posts">
                        <div class="post-item clearfix">
                        <img src="<?php echo e($pn->photo); ?>" alt="">
                        <h4><a href="blog-single.html"><?php echo e($pn->title); ?></a></h4>
                        <time datetime="2020-01-01"><?php echo e(Carbon\Carbon::parse($pn->created_at)->format('d M Y')); ?></time>
                        </div>

                    </div><!-- End sidebar recent posts-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                    </div><!-- End sidebar -->

                </div><!-- End blog sidebar -->

            </div>

        </div>
    </section><!-- End Blog Section -->

</main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\omega_portfolio\resources\views/frontend/newsblog.blade.php ENDPATH**/ ?>