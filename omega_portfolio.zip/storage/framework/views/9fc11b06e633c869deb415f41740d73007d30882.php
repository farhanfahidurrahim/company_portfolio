<?php $__env->startSection('content'); ?>

<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Contact-Us</h2>
          <ol>
            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li>Contact</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <section class="ftco-section contact-section">
        <div class="container">
          <div class="row block-9 mb-4">
            <div class="col-md-6 pr-md-5 flex-column">
              <div class="row d-block flex-row">
                <h2 class="h4 mb-4">Contact Information</h2>
                <div class="col mb-3 d-flex py-4 border" style="background: white;">
                  <div class="align-self-center">
                    <p class="mb-0"><span>Address:</span> <a href="#"> <?php echo e($contact->address); ?></a></p>
                  </div>
                </div>
                <div class="col mb-3 d-flex py-4 border" style="background: white;">
                  <div class="align-self-center">
                    <p class="mb-0"><span>Phone One:</span> <a href="tel://<?php echo e($contact->phone_one); ?>"> <?php echo e($contact->phone_one); ?></a></p>
                  </div>
                </div>
                <div class="col mb-3 d-flex py-4 border" style="background: white;">
                    <div class="align-self-center">
                      <p class="mb-0"><span>Phone Two:</span> <a href="tel://<?php echo e($contact->phone_two); ?>"> <?php echo e($contact->phone_two); ?></a></p>
                    </div>
                  </div>
                <div class="col mb-3 d-flex py-4 border" style="background: white;">
                  <div class="align-self-center">
                    <p class="mb-0"><span>Email:</span> <a href="mailto:<?php echo e($contact->email); ?>"> <?php echo e($contact->email); ?></a></p>
                  </div>
                </div>
                
              </div>
            </div>

            <div class="col-md-6">
            <h2 class="h4 mb-0">Get In Touch!</h2>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('contact.message.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1"></label>
                        <input type="text" class="form-control" id="exampleInputEmail1" name="name" placeholder="Enter Your Full Name">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1"></label>
                        <input type="email" class="form-control" id="exampleInputEmail1" name="email" placeholder="Enter Your Email Address">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1"></label>
                        <input type="text" class="form-control" id="exampleInputEmail1" name="subject" placeholder="Enter Message Subject">
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlTextarea1"></label>
                        <textarea class="form-control" id="exampleFormControlTextarea1" name="message" rows="3" placeholder="Enter Your Message"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1"></label>
                        <input type="number" class="form-control" id="exampleInputEmail1" name="phone" placeholder="Enter Your Phone Number (Optional)">
                    </div>
                    <br>
                    <button type="submit" class="btn btn-primary">Send Message</button>
                </form>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-12" id="map"></div>
        </div>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\omega_portfolio\resources\views/frontend/contact.blade.php ENDPATH**/ ?>