<?php $__env->startSection('content'); ?>

<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h4>Image</h4>
          <ol>
            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li>Image</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Blog Section ======= -->
    <div class="container" data-aos="fade-up">
        <div class="px-lg-5">
          <!-- For demo purpose -->
          <div class="row py-5">
            <div class="col-lg-12 mx-auto">
                <h1>Image Gallery</h1>
                
            </div>
          </div>
          <!-- End -->

          <div class="row">

            <!-- Gallery item -->
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                
                <div class="bg-white rounded shadow-sm"><img src="<?php echo e($item->photo); ?>" alt="" class="img-fluid card-img-top">
                  <div class="p-4">
                    <h5 class="text-dark"><?php echo e($item->title); ?></h5>
                    
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
        </div>
      </div>


</main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\omega_portfolio\resources\views/frontend/gallery/image.blade.php ENDPATH**/ ?>