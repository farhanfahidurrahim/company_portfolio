<div class="footer-top">
    <div class="container">
      <div class="row">
        <?php
            $contact=DB::table('contacts')->first();
        ?>
        <div class="col-lg-3 col-md-6 footer-contact">
          <h3>Company</h3>
          <p>
            <?php echo e($contact->address); ?> <br><br>
            <strong>Phone:</strong> <?php echo e($contact->phone_one); ?><br>
            <strong>Phone:</strong> <?php echo e($contact->phone_two); ?><br>
            <strong>Email:</strong> <?php echo e($contact->email); ?><br>
          </p>
        </div>

        <div class="col-lg-2 col-md-6 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('nav.news')); ?>">News Post</a></li>
            
            <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('nav.contact')); ?>">Contact us</a></li>
            
          </ul>
        </div>

        <div class="col-lg-3 col-md-6 footer-links">
          
        </div>

        <?php
            $social_link=DB::table('social_links')->first();
        ?>
        <div class="col-lg-4 col-md-6 footer-newsletter">
          <h4>Follow Our Social Site</h4>
          <div class="social-links text-center text-md-right pt-3 pt-md-0">
              <a href="<?php echo e($social_link->facebook); ?>" target="_blank" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="<?php echo e($social_link->instagram); ?>" target="_blank" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="<?php echo e($social_link->twitter); ?>" target="_blank" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="<?php echo e($social_link->linkedin); ?>" target="_blank" class="linkedin"><i class="bx bxl-linkedin"></i></a>
          </div>
        </div>

      </div>
    </div>
  </div>

  <div class="container d-md-flex py-4">

    <div class="me-md-auto text-center text-md-start">
      <div class="copyright">
        &copy; Copyright <strong><span>Company</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/company-free-html-bootstrap-template/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
    
  </div>
<?php /**PATH G:\xampp\htdocs\omega_portfolio\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>